import os
import sys
import argparse
import subprocess
import contextlib

# Quiet TensorFlow C++ INFO noise (oneDNN notices) before any import that may
# pull TF in transitively (e.g. transformers BLIP2 / WD14 Keras path).
# setdefault keeps user/shell overrides. Matches setup_environment() for train
# subprocesses (TF_ENABLE_ONEDNN_OPTS).
os.environ.setdefault("TF_ENABLE_ONEDNN_OPTS", "0")
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")

import gradio as gr

from kohya_gui.class_gui_config import KohyaSSGUIConfig
from kohya_gui.dreambooth_gui import dreambooth_tab
from kohya_gui.finetune_gui import finetune_tab
from kohya_gui.textual_inversion_gui import ti_tab
from kohya_gui.utilities import utilities_tab
from kohya_gui.lora_gui import lora_tab
from kohya_gui.leco_gui import leco_tab
from kohya_gui.anima_lllite_gui import anima_lllite_tab
from kohya_gui.class_lora_tab import LoRATools
from kohya_gui.settings_gui import settings_tab
from kohya_gui.custom_logging import setup_logging
from kohya_gui.common_gui import (
    HEADLESS_RECOMMENDATION_MESSAGE,
    should_recommend_headless,
)
from kohya_gui.localization_ext import add_javascript
from kohya_gui.offline_assets import (
    build_offline_theme,
    install_offline_template_patches,
    sanitize_readme_for_about,
)

PYTHON = sys.executable
project_dir = os.path.dirname(os.path.abspath(__file__))


# Function to read file content, suppressing any FileNotFoundError
def read_file_content(file_path):
    with contextlib.suppress(FileNotFoundError):
        with open(file_path, "r", encoding="utf8") as file:
            return file.read()
    return ""


# Function to initialize the Gradio UI interface
def initialize_ui_interface(
    config, config_file_path, headless, use_shell, release_info, readme_content
):
    # Load custom CSS if available
    css = read_file_content("./assets/style.css")
    # Positions the hover-revealed `info=` tooltip (see assets/style.css);
    # always injected, unlike add_javascript() below which only fires when
    # --language is set. The initial enabled/disabled state comes from the
    # Settings tab's persisted config.toml value; the checkbox there
    # live-updates window.KOHYA_INFO_TOOLTIP_ENABLED via its own js= handler.
    enable_info_tooltip = config.get("settings.enable_info_tooltip", True)
    info_tooltip_js = read_file_content("./assets/js/info_tooltip.js")
    icon_button_titles_js = read_file_content("./assets/js/icon_button_titles.js")
    head = (
        f'<script type="text/javascript">window.KOHYA_INFO_TOOLTIP_ENABLED = {str(enable_info_tooltip).lower()};</script>'
        f'<script type="text/javascript">{info_tooltip_js}</script>'
        f'<script type="text/javascript">{icon_button_titles_js}</script>'
    )
    # Gradio 6 moved app-level shell params (css/head/theme) from Blocks() to
    # launch(); keep them bundled here so launch sites stay in sync.
    theme = build_offline_theme()
    shell_params = {"css": css, "head": head, "theme": theme}

    # Create the main Gradio Blocks interface (no analytics)
    ui_interface = gr.Blocks(
        title=f"Kohya_ss GUI {release_info}",
        analytics_enabled=False,
    )
    with ui_interface:
        # Create tabs for different functionalities
        with gr.Tab("Dreambooth"):
            (
                train_data_dir_input,
                reg_data_dir_input,
                output_dir_input,
                logging_dir_input,
            ) = dreambooth_tab(
                headless=headless, config=config, use_shell_flag=use_shell
            )
        with gr.Tab("LoRA"):
            lora_tab(headless=headless, config=config, use_shell_flag=use_shell)
        with gr.Tab("LECO"):
            leco_tab(headless=headless, config=config, use_shell_flag=use_shell)
        with gr.Tab("Anima LLLite"):
            anima_lllite_tab(headless=headless, config=config, use_shell_flag=use_shell)
        with gr.Tab("Textual Inversion"):
            ti_tab(headless=headless, config=config, use_shell_flag=use_shell)
        with gr.Tab("Finetuning"):
            finetune_tab(headless=headless, config=config, use_shell_flag=use_shell)
        with gr.Tab("Utilities"):
            # Utilities tab requires inputs from the Dreambooth tab
            utilities_tab(
                train_data_dir_input=train_data_dir_input,
                reg_data_dir_input=reg_data_dir_input,
                output_dir_input=output_dir_input,
                logging_dir_input=logging_dir_input,
                headless=headless,
                config=config,
            )
            with gr.Tab("LoRA"):
                _ = LoRATools(headless=headless)
        with gr.Tab("Settings"):
            settings_tab(config=config, config_file_path=config_file_path)
        with gr.Tab("About"):
            # About tab to display release information and README content
            gr.Markdown(f"kohya_ss GUI release {release_info}")
            with gr.Tab("README"):
                gr.Markdown(readme_content)

        # Display release information in a div element
        gr.Markdown(f"<div class='ver-class'>{release_info}</div>")

    return ui_interface, shell_params


# Function to configure and launch the UI
def UI(**kwargs):
    # Offline HTML patch first so localization's TemplateResponse wrapper (if any)
    # still chains through GrRoutesTemplateResponse after CDN/font rewrites.
    install_offline_template_patches()
    # Add custom JavaScript if specified
    add_javascript(kwargs.get("language"))
    headless = kwargs.get("headless", False)
    log.info(f"headless: {headless}")
    if should_recommend_headless(headless):
        log.warning(HEADLESS_RECOMMENDATION_MESSAGE)

    # Load release and README information
    release_info = read_file_content("./.release")
    # Strip remote badges/images so About does not fetch third-party hosts.
    readme_content = sanitize_readme_for_about(read_file_content("./README.md"))

    # Load configuration from the specified file
    config_file_path = kwargs.get("config") or "./config.toml"
    config = KohyaSSGUIConfig(config_file_path=config_file_path)
    if config.is_config_loaded():
        log.info(f"Loaded default GUI values from '{config_file_path}'...")

    # Determine if shell should be used for running external commands
    use_shell = not kwargs.get("do_not_use_shell", False) and config.get(
        "settings.use_shell", True
    )
    if use_shell:
        log.info("Using shell=True when running external commands...")

    # Initialize the Gradio UI interface (shell css/head/theme come back for launch)
    ui_interface, shell_params = initialize_ui_interface(
        config,
        config_file_path,
        headless,
        use_shell,
        release_info,
        readme_content,
    )

    # Construct launch parameters using dictionary comprehension
    launch_params = {
        "server_name": kwargs.get("listen"),
        "auth": (
            (kwargs["username"], kwargs["password"])
            if kwargs.get("username") and kwargs.get("password")
            else None
        ),
        "server_port": (
            kwargs.get("server_port", 0) if kwargs.get("server_port", 0) > 0 else None
        ),
        "inbrowser": kwargs.get("inbrowser", False),
        "share": (
            False if kwargs.get("do_not_share", False) else kwargs.get("share", False)
        ),
        "root_path": kwargs.get("root_path", None),
        "debug": kwargs.get("debug", False),
        "allowed_paths": config.allowed_paths,
        # Gradio 6: app-level shell params belong on launch(), not Blocks().
        **shell_params,
    }

    # This line filters out any key-value pairs from `launch_params` where the value is `None`, ensuring only valid parameters are passed to the `launch` function.
    launch_params = {k: v for k, v in launch_params.items() if v is not None}

    # Launch the Gradio interface with the specified parameters
    ui_interface.launch(**launch_params)


# Function to initialize argument parser for command-line arguments
def initialize_arg_parser():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--config",
        type=str,
        default="./config.toml",
        help="Path to the toml config file for interface defaults",
    )
    parser.add_argument("--debug", action="store_true", help="Debug on")
    parser.add_argument(
        "--listen",
        type=str,
        default="127.0.0.1",
        help="IP to listen on for connections to Gradio",
    )
    parser.add_argument(
        "--username", type=str, default="", help="Username for authentication"
    )
    parser.add_argument(
        "--password", type=str, default="", help="Password for authentication"
    )
    parser.add_argument(
        "--server_port", type=int, default=0, help="Port to run the server listener on"
    )
    parser.add_argument("--inbrowser", action="store_true", help="Open in browser")
    parser.add_argument("--share", action="store_true", help="Share the gradio UI")
    parser.add_argument(
        "--headless",
        action="store_true",
        help=(
            "Run without local GUI dialogs: hide file/folder picker buttons and "
            "skip easygui overwrite confirmation (required for remote/SSH; "
            "existing models are overwritten without a prompt)"
        ),
    )
    parser.add_argument(
        "--language", type=str, default=None, help="Set custom language"
    )
    parser.add_argument(
        "--use-ipex",
        action="store_true",
        help="Use native PyTorch XPU environment for Intel Arc GPUs (legacy flag name)",
    )
    parser.add_argument("--use-rocm", action="store_true", help="Use ROCm environment")
    parser.add_argument(
        "--do_not_use_shell",
        action="store_true",
        help="Enforce not to use shell=True when running external commands",
    )
    parser.add_argument(
        "--do_not_share", action="store_true", help="Do not share the gradio UI"
    )
    parser.add_argument(
        "--requirements",
        type=str,
        default=None,
        help="requirements file to use for validation",
    )
    parser.add_argument(
        "--root_path",
        type=str,
        default=None,
        help="`root_path` for Gradio to enable reverse proxy support. e.g. /kohya_ss",
    )
    parser.add_argument(
        "--noverify", action="store_true", help="Disable requirements verification"
    )
    return parser


if __name__ == "__main__":
    # Initialize argument parser and parse arguments
    parser = initialize_arg_parser()
    args = parser.parse_args()

    # Set up logging based on the debug flag
    log = setup_logging(debug=args.debug)

    # Verify requirements unless `noverify` flag is set.
    # gui-uv.* always passes --noverify (uv owns deps); log at info, not warning.
    if args.noverify:
        log.info("Skipping requirements verification.")
    else:
        # Run the validation command to verify requirements
        validation_command = [
            PYTHON,
            os.path.join(project_dir, "setup", "validate_requirements.py"),
        ]

        if args.requirements is not None:
            validation_command.append(f"--requirements={args.requirements}")

        subprocess.run(validation_command, check=True)

    # Launch the UI with the provided arguments
    UI(**vars(args))
